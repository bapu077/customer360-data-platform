# System Architecture
- ETL -> Customer360 -> Dashboard